 wemos-d1-mini-kicad
==============
KiCAD

* library, 
* footprint and 
* 3D shape 

of the WeMos D1 mini board. 

The library provides several footprints and shape alignments:

![butler 3d view](https://github.com/rubienr/wemos-d1-mini-kicad/blob/master/meta/illustration1.png)
![butler 3d view](https://github.com/rubienr/wemos-d1-mini-kicad/blob/master/meta/illustration2.png)
![butler 3d view](https://github.com/rubienr/wemos-d1-mini-kicad/blob/master/meta/illustration3.png)
![butler 3d view](https://github.com/rubienr/wemos-d1-mini-kicad/blob/master/meta/illustration4.png)
